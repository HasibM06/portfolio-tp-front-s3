const canvas = document.querySelector("#c2");
const ctx = canvas.getContext("2d");

function drawPacman() {
  const w = canvas.width;
  const h = canvas.height;

  // Fond noir
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = "#000";
  ctx.fillRect(0, 0, w, h);

  /* === Pacman CENTRÉ (modif principale) === */
  const cx = w / 2;
  const cy = h / 2;
  const r  = Math.min(w, h) * 0.30;

  // Bouche
  const mouth = Math.PI / 6;
  const start = mouth;
  const end   = 2 * Math.PI - mouth;

  // Corps Pacman
  ctx.beginPath();
  ctx.moveTo(cx, cy);
  ctx.arc(cx, cy, r, start, end);
  ctx.closePath();
  ctx.fillStyle = "#FFD400";
  ctx.fill();

  // Œil noir
  ctx.beginPath();
  ctx.arc(cx + r * 0.18, cy - r * 0.35, r * 0.12, 0, 2 * Math.PI);
  ctx.fillStyle = "#000";
  ctx.fill();

  // Reflet blanc
  ctx.beginPath();
  ctx.arc(
    cx + r * 0.22,
    cy - r * 0.38,
    r * 0.04,
    0,
    2 * Math.PI
  );
  ctx.fillStyle = "#fff";
  ctx.fill();

  // Points blancs
  ctx.beginPath();
  ctx.arc(cx + r * 1.05, cy, r * 0.06, 0, 2 * Math.PI);
  ctx.arc(cx + r * 1.40, cy, r * 0.06, 0, 2 * Math.PI);
  ctx.fillStyle = "#fff";
  ctx.fill();
}

drawPacman();
