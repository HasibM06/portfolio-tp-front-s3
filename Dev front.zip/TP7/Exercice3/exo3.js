const canvas = document.querySelector("#c3");
const ctx = canvas.getContext("2d");

const btnW = document.querySelector("#btnW");
const btnH = document.querySelector("#btnH");
const btnColor = document.querySelector("#btnColor");
const btnStyle = document.querySelector("#btnStyle");
const btnVis = document.querySelector("#btnVis");

// État initial (consigne)
const rect = {
  x: 50,
  y: 50,
  w: 50,
  h: 50,
  colors: ["yellow", "red", "blue", "green"],
  colorIndex: 0,
  filled: true,
  visible: true
};

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  if (!rect.visible) return;

  ctx.fillStyle = rect.colors[rect.colorIndex];
  ctx.strokeStyle = rect.colors[rect.colorIndex];
  ctx.lineWidth = 3;

  if (rect.filled) {
    ctx.fillRect(rect.x, rect.y, rect.w, rect.h);
  } else {
    ctx.strokeRect(rect.x, rect.y, rect.w, rect.h);
  }
}

btnW.addEventListener("click", () => {
  rect.w += 10;
  if (rect.w > 200) rect.w = 10;
  draw();
});

btnH.addEventListener("click", () => {
  rect.h += 10;
  if (rect.h > 200) rect.h = 10;
  draw();
});

btnColor.addEventListener("click", () => {
  rect.colorIndex = (rect.colorIndex + 1) % rect.colors.length;
  draw();
});

btnStyle.addEventListener("click", () => {
  rect.filled = !rect.filled;
  draw();
});

btnVis.addEventListener("click", () => {
  rect.visible = !rect.visible;
  draw();
});

draw();
