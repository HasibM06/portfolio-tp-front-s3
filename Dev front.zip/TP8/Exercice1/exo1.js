const canvas = document.querySelector("#c1");
const ctx = canvas.getContext("2d");


const bg = new Image();
bg.src = "pelouse.png";

const sprites = new Image();
sprites.src = "sprites.png";


const CELL = 128;


const DIR_ROW = {
  down: 0,
  up: 1,
  left: 2,
  right: 3
};

// Perso
const player = {
  x: 0,
  y: 0,
  w: 64, 
  h: 64,
  dir: "down",
  frame: 0,  
  speed: 8
};


player.x = (canvas.width - player.w) / 2;
player.y = (canvas.height - player.h) / 2;

function clamp(v, min, max){
  return Math.max(min, Math.min(max, v));
}

function draw(){
  
  if (bg.complete) {
    for (let y = 0; y < canvas.height; y += bg.height) {
      for (let x = 0; x < canvas.width; x += bg.width) {
        ctx.drawImage(bg, x, y);
      }
    }
  } else {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  }

  
  if (sprites.complete) {
    const sx = player.frame * CELL;
    const sy = DIR_ROW[player.dir] * CELL;

    ctx.drawImage(
      sprites,
      sx, sy, CELL, CELL,
      Math.round(player.x), Math.round(player.y), player.w, player.h
    );
  }
}


window.addEventListener("keydown", (e) => {
  const key = e.key;

  
  if (["ArrowUp","ArrowDown","ArrowLeft","ArrowRight"].includes(key)) {
    e.preventDefault();
  } else {
    return;
  }

  
  if (key === "ArrowUp") {
    player.dir = "up";
    player.y -= player.speed;
  } else if (key === "ArrowDown") {
    player.dir = "down";
    player.y += player.speed;
  } else if (key === "ArrowLeft") {
    player.dir = "left";
    player.x -= player.speed;
  } else if (key === "ArrowRight") {
    player.dir = "right";
    player.x += player.speed;
  }

  
  player.frame = (player.frame + 1) % 4;

  
  player.x = clamp(player.x, 0, canvas.width - player.w);
  player.y = clamp(player.y, 0, canvas.height - player.h);

  draw();
});


let loaded = 0;
function onLoad(){
  loaded++;
  if (loaded === 2) draw();
}
bg.onload = onLoad;
sprites.onload = onLoad;
