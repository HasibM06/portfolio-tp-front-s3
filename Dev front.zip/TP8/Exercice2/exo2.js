const canvas = document.querySelector("#c2");
const ctx = canvas.getContext("2d");


const fond = new Image();
fond.src = "fond.png"; 

const marioSheet = new Image();
marioSheet.src = "mario.png"; 


const FRAME = 92;
const COLS = 5;
const TOTAL_FRAMES = 24; 

let bgX = 0;
const bgSpeed = 1.5;

let tick = 0;
let frameIndex = 0;


const mario = {
  x: canvas.width * 0.42,
  y: canvas.height - 92 - 90, 
  w: 92,
  h: 92
};

function drawBackground(){
  
  ctx.drawImage(fond, Math.round(bgX), 0);
  ctx.drawImage(fond, Math.round(bgX + fond.width), 0);
}

function drawMario(){
  const sx = (frameIndex % COLS) * FRAME;
  const sy = Math.floor(frameIndex / COLS) * FRAME;

  ctx.drawImage(
    marioSheet,
    sx, sy, FRAME, FRAME,
    Math.round(mario.x), Math.round(mario.y), mario.w, mario.h
  );
}

function animate(){
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  
  bgX -= bgSpeed;
  if (bgX <= -fond.width) bgX += fond.width;

  drawBackground();

  
  tick++;
  if (tick % 6 === 0) { 
    frameIndex = (frameIndex + 1) % TOTAL_FRAMES;
  }

  drawMario();

  requestAnimationFrame(animate);
}


let loaded = 0;
function onLoad(){
  loaded++;
  if (loaded === 2) requestAnimationFrame(animate);
}
fond.onload = onLoad;
marioSheet.onload = onLoad;
