var image = document.getElementById("monImage");
var btnStart = document.getElementById("btnStart");
var btnStop = document.getElementById("btnStop");

var intervalID = null;


function startAnimation() {
   
    if (intervalID === null) {
      
        intervalID = setInterval(deformer, 1000);
    }
}


function stopAnimation() {

    clearInterval(intervalID);
    intervalID = null;
}


function deformer() {
 
    var a = 0.8 + Math.random() * 0.4; 
    var d = 0.8 + Math.random() * 0.4; 
    
    
    var b = (Math.random() - 0.5) * 0.5; 
    var c = (Math.random() - 0.5) * 0.5;
    
   
    var tx = (Math.random() - 0.5) * 60;
    var ty = (Math.random() - 0.5) * 60;

    
    image.style.transform = "matrix(" + a + "," + b + "," + c + "," + d + "," + tx + "," + ty + ")";
}


btnStart.addEventListener("click", startAnimation);
btnStop.addEventListener("click", stopAnimation);